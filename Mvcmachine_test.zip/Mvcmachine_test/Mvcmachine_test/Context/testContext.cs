﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace Mvcmachine_test.Context
{
    public class testContext:DbContext
    {
        public DbSet<Test> info { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Test>().MapToStoredProcedures();
            base.OnModelCreating(modelBuilder);
        }        
     
    }
}